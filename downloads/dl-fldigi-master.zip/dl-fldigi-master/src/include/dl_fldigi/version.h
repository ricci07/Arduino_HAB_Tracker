#ifndef DL_FLDIGI_VERSION_H
#define DL_FLDIGI_VERSION_H

namespace dl_fldigi {

extern const char *git_commit;
extern const char *git_short_commit;

}

#endif
