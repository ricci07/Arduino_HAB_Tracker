#!/bin/bash


cp images/event-log-debug.png ../user_docs/latex/event-log-debug.png
cp images/event-log-error.png ../user_docs/latex/event-log-error.png
cp images/event-log-info.png ../user_docs/latex/event-log-info.png
cp images/event-log-quiet.png ../user_docs/latex/event-log-quiet.png
cp images/event-log-verbose.png ../user_docs/latex/event-log-verbose.png
cp images/event-log-warning.png ../user_docs/latex/event-log-warning.png
cp images/digiscope-psk-nosig.png ../user_docs/latex/digiscope-psk-nosig.png
cp images/digiscope-psk.png ../user_docs/latex/digiscope-psk.png
cp images/digiscope-psk-low.png ../user_docs/latex/digiscope-psk-low.png
cp images/digiscope-psk-high.png ../user_docs/latex/digiscope-psk-high.png
cp images/digiscope-psk-history.png ../user_docs/latex/digiscope-psk-history.png
cp images/digiscope-psk-history-amplitude.png ../user_docs/latex/digiscope-psk-history-amplitude.png
cp images/wwv3.png ../user_docs/latex/wwv3.png
cp images/wwv1-lgneg.png ../user_docs/latex/wwv1-lgneg.png
cp images/wwv2-000ppm.png ../user_docs/latex/wwv2-000ppm.png
cp images/wwv2-lgpos.png ../user_docs/latex/wwv2-lgpos.png
cp images/wwv2-125ppm.png ../user_docs/latex/wwv2-125ppm.png
cp images/dcf77-0.png ../user_docs/latex/dcf77-0.png
cp images/dcf77-0zoom.png ../user_docs/latex/dcf77-0zoom.png
cp images/dcf77-1000.png ../user_docs/latex/dcf77-1000.png
cp images/dcf77-65zoom.png ../user_docs/latex/dcf77-65zoom.png
cp images/RWMpre-cal.png ../user_docs/latex/RWMpre-cal.png
cp images/RWM+25361ppm.png ../user_docs/latex/RWM+25361ppm.png
cp images/RWMpost-cal-x5.png ../user_docs/latex/RWMpost-cal-x5.png




