#!/bin/bash

# Distribution clean of documents

rm -rf pdf/
rm -rf compressed_html/
rm -rf user_docs/
rm -rf prog_docs/

